package Logger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ParameterizedLoggingExample {

    private static final Logger logger = LoggerFactory.getLogger(ParameterizedLoggingExample.class);

    public static void main(String[] args) {
        String username = "sonasri";
        int loginCount = 5;

        logger.info("User {} has logged in {} times.", username, loginCount);
        logger.warn("User {} is nearing the login attempt limit!", username);
        logger.error("User {} encountered an error after {} attempts.", username, loginCount);
    }
}
