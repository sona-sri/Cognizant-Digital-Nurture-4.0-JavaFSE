module JUnitDemo {
	requires junit;
}