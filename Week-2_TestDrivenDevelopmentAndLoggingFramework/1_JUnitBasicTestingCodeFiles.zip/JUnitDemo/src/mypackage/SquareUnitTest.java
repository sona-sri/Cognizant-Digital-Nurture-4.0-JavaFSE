package mypackage;


import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.After;
import org.junit.Test;

public class SquareUnitTest {

    private Calculator calc;

    @Before
    public void setUp() {
        calc = new Calculator(); // Arrange
    }

    @After
    public void tearDown() {
        calc = null; // Clean up
    }

    @Test
    public void testSquareOf3() {
        int result = calc.square(3); // Act
        assertEquals(9, result);     // Assert
    }

    @Test
    public void testSquareOf0() {
        assertEquals(0, calc.square(0));
    }

    @Test
    public void testSquareOfNegative() {
        assertEquals(4, calc.square(-2));
    }
}

