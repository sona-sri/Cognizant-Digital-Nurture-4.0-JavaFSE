package mypackage;

public class Calculator {
    public int add(int a, int b) {
        return a + b;
    }
    
    public int square(int a) {
    	return a*a;
    }
}
