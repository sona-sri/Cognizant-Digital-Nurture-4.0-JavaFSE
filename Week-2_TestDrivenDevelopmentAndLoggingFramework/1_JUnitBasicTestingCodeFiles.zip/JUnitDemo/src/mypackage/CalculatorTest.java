package mypackage;

import static org.junit.Assert.*;

import org.junit.Test;

public class CalculatorTest {

	@Test
	public void test() {
		Calculator calc = new Calculator();
		int res = calc.add(2, 3);
		assertEquals(5, res);
	}
}
