/**
 * 
 */
/**
 * 
 */
module JUnitDemo {
	requires junit;
}