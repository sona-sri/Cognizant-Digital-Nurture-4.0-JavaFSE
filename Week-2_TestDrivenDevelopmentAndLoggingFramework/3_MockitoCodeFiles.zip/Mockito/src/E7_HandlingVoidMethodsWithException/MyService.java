package E7_HandlingVoidMethodsWithException;

public class MyService {
    private ExternalApi api;

    public MyService(ExternalApi api) {
        this.api = api;
    }

    public void remove(String id) {
        api.deleteData(id);
    }
}
