package E7_HandlingVoidMethodsWithException;

import static org.mockito.Mockito.*;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;

public class MyServiceTest {

    @Test
    public void testVoidMethodThrowsException() {
        ExternalApi mockApi = Mockito.mock(ExternalApi.class);
        doThrow(new RuntimeException("Deletion failed")).when(mockApi).deleteData("123");
        MyService service = new MyService(mockApi);
        assertThrows(RuntimeException.class, () -> service.remove("123"));
        verify(mockApi).deleteData("123");
    }
}
