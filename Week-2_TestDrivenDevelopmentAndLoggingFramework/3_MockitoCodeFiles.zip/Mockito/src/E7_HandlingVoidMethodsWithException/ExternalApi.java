package E7_HandlingVoidMethodsWithException;

public interface ExternalApi {
    void deleteData(String id);
}

