package E5_MockingAndStubbingMultipleRuns;

import static org.mockito.Mockito.*;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import static org.junit.jupiter.api.Assertions.*;

public class MyServiceTest {

    @Test
    public void testMultipleReturns() {
        ExternalApi mockApi = Mockito.mock(ExternalApi.class);
        when(mockApi.getStatus())
            .thenReturn("Pending")
            .thenReturn("Processing")
            .thenReturn("Completed");
        MyService service = new MyService(mockApi);
        String[] result = service.checkStatusMultipleTimes();
        assertArrayEquals(new String[] {"Pending", "Processing", "Completed"}, result);
    }
}
