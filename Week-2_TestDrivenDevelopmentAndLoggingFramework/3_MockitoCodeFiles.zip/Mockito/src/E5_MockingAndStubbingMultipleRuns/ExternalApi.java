package E5_MockingAndStubbingMultipleRuns;

public interface ExternalApi {
    String getStatus();
}

