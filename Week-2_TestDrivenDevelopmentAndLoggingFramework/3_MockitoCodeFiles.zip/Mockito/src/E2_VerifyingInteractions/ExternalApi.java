package E2_VerifyingInteractions;

public interface ExternalApi {
    void getData();
}
