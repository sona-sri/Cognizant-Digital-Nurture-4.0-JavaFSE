package E3_ArgumentMatching;

public interface ExternalApi {
    void sendData(String key, int value);
}
