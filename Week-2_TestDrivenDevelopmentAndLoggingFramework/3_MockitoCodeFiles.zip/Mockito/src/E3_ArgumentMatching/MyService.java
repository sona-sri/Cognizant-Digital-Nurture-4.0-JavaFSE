package E3_ArgumentMatching;

public class MyService {
    private ExternalApi api;

    public MyService(ExternalApi api) {
        this.api = api;
    }

    public void updateData() {
        api.sendData("user123", 42);
    }
}
