package E4_HandlingVoidMethods;

public interface ExternalApi {
    void logEvent(String message);
}
