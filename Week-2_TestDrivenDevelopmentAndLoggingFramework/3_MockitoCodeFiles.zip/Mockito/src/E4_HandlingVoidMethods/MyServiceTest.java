package E4_HandlingVoidMethods;

import static org.mockito.Mockito.*;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class MyServiceTest {

    @Test
    public void testVoidMethod() {
        ExternalApi mockApi = Mockito.mock(ExternalApi.class);
        doNothing().when(mockApi).logEvent(anyString());
        MyService service = new MyService(mockApi);
        service.process();
        verify(mockApi).logEvent("Process started");
    }
}
