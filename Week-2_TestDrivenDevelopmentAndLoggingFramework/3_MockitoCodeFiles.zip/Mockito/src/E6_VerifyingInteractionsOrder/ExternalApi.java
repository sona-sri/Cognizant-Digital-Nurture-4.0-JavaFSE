package E6_VerifyingInteractionsOrder;

public interface ExternalApi {
    void connect();
    void fetchData();
    void disconnect();
}


