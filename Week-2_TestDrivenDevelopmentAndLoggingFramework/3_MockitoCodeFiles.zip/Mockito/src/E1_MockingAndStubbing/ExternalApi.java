package E1_MockingAndStubbing;

public interface ExternalApi {
    String getData();
}