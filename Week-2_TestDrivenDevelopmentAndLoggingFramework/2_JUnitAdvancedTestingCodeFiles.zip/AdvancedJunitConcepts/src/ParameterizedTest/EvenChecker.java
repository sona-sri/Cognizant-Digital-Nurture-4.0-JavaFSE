package ParameterizedTest;

public class EvenChecker {
    public boolean isEven(int number) {
        return number % 2 == 0;
    }
}
