package PerformanceTest;

public class PerformanceTester {
    public void performTask() throws InterruptedException {
        // Simulates a task that takes 200 ms
        Thread.sleep(200);
    }
}
