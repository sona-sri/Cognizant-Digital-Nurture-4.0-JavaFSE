package OrderedTest;


import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class OrderedTest {

    @Test
    @Order(3)
    void testLogin() {
        System.out.println("Running: testLogin");
        assertTrue(true);
    }

    @Test
    @Order(2)
    void testSearch() {
        System.out.println("Running: testSearch");
        assertTrue(true);
    }

    @Test
    @Order(1)
    void testLogout() {
        System.out.println("Running: testLogout");
        assertTrue(true);
    }
}
