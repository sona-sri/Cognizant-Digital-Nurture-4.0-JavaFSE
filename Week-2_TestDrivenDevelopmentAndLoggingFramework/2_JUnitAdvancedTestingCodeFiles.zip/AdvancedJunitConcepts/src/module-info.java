/**
 * 
 */
/**
 * 
 */
module AdvancedJunitConcepts {
	requires junit;
	requires org.junit.jupiter.params;
	requires org.junit.platform.suite.api;
}