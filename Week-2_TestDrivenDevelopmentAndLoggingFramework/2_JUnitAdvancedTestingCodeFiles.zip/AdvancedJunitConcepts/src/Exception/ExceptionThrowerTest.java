package Exception;

import static org.junit.Assert.*;
import org.junit.Test;

public class ExceptionThrowerTest {

    @Test(expected = IllegalArgumentException.class)
    public void testThrowsException() {
        ExceptionThrower obj = new ExceptionThrower();
        obj.throwException(null);
    }

    @Test
    public void testDoesNotThrow() {
        ExceptionThrower obj = new ExceptionThrower();
        try {
            obj.throwException("Hello");
        } catch (Exception e) {
            fail("Should not throw exception");
        }
    }
}

