package SuitesAndCategories;


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class AdditionTest {

    @Test
    void testAdd() {
        assertEquals(5, 2 + 3);
    }
}