package SuitesAndCategories;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class MultiplicationTest {

    @Test
    void testMultiply() {
        assertEquals(6, 2 * 3);
    }
}
