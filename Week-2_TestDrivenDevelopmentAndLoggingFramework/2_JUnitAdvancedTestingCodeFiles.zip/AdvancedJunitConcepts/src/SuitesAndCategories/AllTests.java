package SuitesAndCategories;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

@Suite
@SelectClasses({
    AdditionTest.class,
    MultiplicationTest.class
})
public class AllTests {
    // No methods needed; this class is just a container for the suite
}