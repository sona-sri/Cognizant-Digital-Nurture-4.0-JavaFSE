package E3_MockingFileIO;

public interface FileWriter {
    void write(String content);
}
