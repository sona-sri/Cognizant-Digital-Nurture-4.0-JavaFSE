package E3_MockingFileIO;

public interface FileReader {
    String read();
}

