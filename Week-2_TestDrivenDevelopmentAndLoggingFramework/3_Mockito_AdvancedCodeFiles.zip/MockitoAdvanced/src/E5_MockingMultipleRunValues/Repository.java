package E5_MockingMultipleRunValues;

public interface Repository {
    String getData();
}
