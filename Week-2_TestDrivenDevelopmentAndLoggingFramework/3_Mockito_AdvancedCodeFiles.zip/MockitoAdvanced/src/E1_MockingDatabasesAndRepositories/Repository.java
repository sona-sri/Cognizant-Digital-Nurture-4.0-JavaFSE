package E1_MockingDatabasesAndRepositories;

public interface Repository {
    String getData();
}

