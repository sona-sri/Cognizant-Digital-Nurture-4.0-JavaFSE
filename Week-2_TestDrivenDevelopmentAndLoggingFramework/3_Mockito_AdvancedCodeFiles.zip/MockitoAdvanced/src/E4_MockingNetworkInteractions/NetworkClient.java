package E4_MockingNetworkInteractions;

public interface NetworkClient {
    String connect();
}
