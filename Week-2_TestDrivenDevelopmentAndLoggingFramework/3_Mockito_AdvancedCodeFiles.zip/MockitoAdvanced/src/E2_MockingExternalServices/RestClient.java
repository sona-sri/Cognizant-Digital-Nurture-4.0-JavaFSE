package E2_MockingExternalServices;

public interface RestClient {
    String getResponse();
}
